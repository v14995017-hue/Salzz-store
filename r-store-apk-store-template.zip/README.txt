R STORE — template toko APK
- Edit daftar produk di index.html pada const products.
- Ganti nomor WhatsApp di fungsi checkout().
- Template ini untuk aplikasi/tools Android yang legal dan tidak mengganggu akun atau layanan pihak lain.
